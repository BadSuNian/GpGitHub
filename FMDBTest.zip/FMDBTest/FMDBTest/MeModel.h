//
//  MeModel.h
//  FMDBTest
//
//  Created by qingsong on 15/6/3.
//  Copyright (c) 2015年 qingsong. All rights reserved.
//

@interface MeModel : NSObject

//@property (nonatomic)int index;

@property (nonatomic,copy)NSString * index_Me;

@property (nonatomic, copy) NSString * personid;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *sex;

@property (nonatomic, copy) NSString *school;

@property (nonatomic, copy) NSString *my_ages;

@property (nonatomic, copy) NSString *avatar;

@property (nonatomic, copy) NSString *bigAvatar;
//
//@property (nonatomic, copy) NSString *year;
//
@property (nonatomic, copy) NSString * age;
//
//@property (nonatomic, assign) NSInteger ID_No;



@end
